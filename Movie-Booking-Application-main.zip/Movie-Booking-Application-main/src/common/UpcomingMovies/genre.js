let Genres = [
    {
        id: 1,
        name: "Action"
    },
    {
        id: 2,
        name: "Sci-Fi"
    },
    {
        id: 3,
        name: "Drama"
    },
    {
        id: 4,
        name: "Crime"
    },
    {
        id: 5,
        name: "Adventure"
    },
    {
        id: 6,
        name: "Biography"
    },
    {
        id: 7,
        name: "Horror"
    },
    {
        id: 8,
        name: "Suspense"
    }
]

export default Genres;